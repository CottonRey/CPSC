Colton Reiher
2398791
reiher@chapman.edu
CPSC-350-03
Assignment #4

----------------
Submitted Files:

main.cpp
DblList.h
ListNode.h
DNASeq.h
DNASeq.cpp
PalindromeFinder.h
PalindromeFinder.cpp
Input.txt

-------
Errors:

No known compile or runtime errors, code limitations, or deviations from assignment specifications.

-----------
References:

https://devdocs.io/cpp/

-------------
Instructions:

Commands to compile into executible and run program:

g++ *.cpp -o fourthProject.exe
./fourthProject.exe Input.txt

Running the program will gather the genetic sequences from the input file, determining any genetic palindromes, as well as substrings of the sequences that are also genetic palindromes.