// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #4

#ifndef DNA_SEQ_H
#define DNA_SEQ_H

#include "DblList.h"

class DNASeq {
public:
    DNASeq();
    ~DNASeq();
    DNASeq(const std::string& sequence);
    DNASeq complement();
    DNASeq substring(int start, int end);
    bool isGeneticPalindrome();
    int getSize() const;  // Add the function declaration
    const DblList<char>& getDnaList() const;
private:
    DblList<char> dnaList;
};

#endif
