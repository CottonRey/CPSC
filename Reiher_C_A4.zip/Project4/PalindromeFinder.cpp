// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #4

#include "PalindromeFinder.h"
#include <fstream>
#include <iostream>

void PalindromeFinder::findPalindromes(const std::string& filename) {
    std::ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        std::cerr << "Error: Could not open file." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        if (line == "END") {
            break;
        }

        DNASeq dnaSequence(line);

        // Check if the sequence is valid
        bool validSequence = true;
        const DblList<char>& sequenceList = dnaSequence.getDnaList();
        for (int i = 0; i < sequenceList.size(); ++i) {
            char nucleotide = sequenceList.get(i);
            if (nucleotide != 'A' && nucleotide != 'T' && nucleotide != 'C' && nucleotide != 'G') {
                std::cout << line.substr(0, sequenceList.size()) << " - INVALID" << std::endl;
                validSequence = false;
                break;
            }
        }

        if (validSequence) {
            // Check if it's a genetic palindrome
            bool isPalindrome = dnaSequence.isGeneticPalindrome();
            if (isPalindrome) {
                std::cout <<  line.substr(0, sequenceList.size()) << " - Genetic Palindrome" << std::endl;
            } else {
                std::cout << line.substr(0, sequenceList.size()) << " - Not a Genetic Palindrome" << std::endl;
            }

            // Find and print genetic palindrome substrings
            for (int start = 0; start < sequenceList.size() - 4; ++start) {
                for (int end = start + 5; end <= sequenceList.size(); ++end) {
                    DNASeq substring = dnaSequence.substring(start, end);
                    if (substring.isGeneticPalindrome()) {
                        std::cout << " Substring " << line.substr(start, end - start) << " - Genetic Palindrome" << std::endl;
                    }
                }
            }
        }
    }

    inputFile.close();
}
