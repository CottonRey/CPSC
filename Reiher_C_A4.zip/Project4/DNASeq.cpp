// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #4

#include "DNASeq.h"
#include <cctype>

DNASeq::DNASeq() {
    // Default constructor
}

DNASeq::DNASeq(const std::string& sequence) {
    for (char nucleotide : sequence) {
        if (nucleotide == 'A' || nucleotide == 'T' || nucleotide == 'C' || nucleotide == 'G') {
            dnaList.addBack(nucleotide);
        } else if (isalpha(nucleotide)) {
            dnaList.addBack(nucleotide);
        }
    }
}

DNASeq::~DNASeq() {
}

// Create the complement of the genetic sequence
DNASeq DNASeq::complement() {
    DNASeq complementedSeq;
    for (int i = 0; i < dnaList.size(); ++i) {
        char nucleotide = dnaList.get(i);
        char complement;
        if (nucleotide == 'A') {
            complement = 'T';
        } else if (nucleotide == 'T') {
            complement = 'A';
        } else if (nucleotide == 'C') {
            complement = 'G';
        } else if (nucleotide == 'G') {
            complement = 'C';
        } else {
        }
        complementedSeq.dnaList.addBack(complement);
    }
    return complementedSeq;
}

// Get substring of genetic sequence
DNASeq DNASeq::substring(int start, int end) {
    DNASeq substringSeq;
    for (int i = start; i < end; ++i) {
        char nucleotide = dnaList.get(i);
        substringSeq.dnaList.addBack(nucleotide);
    }
    return substringSeq;
}

// Get size of list
int DNASeq::getSize() const {
    return dnaList.size();
}

// Return list
const DblList<char>& DNASeq::getDnaList() const {
    return dnaList;
}

bool DNASeq::isGeneticPalindrome() {
    // Check if the sequence is a genetic palindrome
    DNASeq complementedSeq = complement();
    for (int i = 0; i < dnaList.size(); ++i) {
        if (dnaList.get(i) != complementedSeq.dnaList.get(dnaList.size() - 1 - i)) {
            return false;
        }
    }
    return true;
}
