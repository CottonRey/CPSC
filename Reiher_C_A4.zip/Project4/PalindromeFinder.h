// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #4

#ifndef PALINDROME_FINDER_H
#define PALINDROME_FINDER_H

#include "DNASeq.h"

class PalindromeFinder {
public:
    static void findPalindromes(const std::string& filename);
};

#endif
