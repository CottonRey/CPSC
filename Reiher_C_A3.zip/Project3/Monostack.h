// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #3

#ifndef MONOSTACK_H
#define MONOSTACK_H

template <typename T>
class MonoStack {
public:
    MonoStack(int initialSize, char o);
    ~MonoStack();
    bool isEmpty() const;
    void push(T value);
    void pop();
    T topValue() const;

private:
    int size;
    char order;
    T* data;
    int top;
};

#endif  // MONOSTACK_H
