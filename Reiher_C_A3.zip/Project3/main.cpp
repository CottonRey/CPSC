// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #3

#include <iostream>
#include "SpeakerView.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file>" << std::endl;
        return 1;
    }

    const std::string inputFileName = argv[1]; // Store the input file name in a variable

    try {
        std::cout << "Opening file: " << inputFileName << std::endl; // Debugging output
        SpeakerView speakerView(inputFileName);
        speakerView.computeView();
        speakerView.printView();
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
