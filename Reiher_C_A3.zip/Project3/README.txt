Colton Reiher
2398791
reiher@chapman.edu
CPSC-350-03
Assignment #3

----------------
Submitted Files:

main.cpp
Monostack.h
Monostack.cpp
SpeakerView.h
SpeakerView.cpp

-------
Errors:

No known compile or runtime errors, code limitations, or deviations from assignment specifications.

-----------
References:

https://devdocs.io/cpp/

-------------
Instructions:

Commands to compile into executible and run program:

g++ *.cpp -o thirdProject.exe
./thirdProject.exe input.txt

Running the program will gather the seating data from the input.txt file, calculate the
amount of people in each column who can see, and print the results to the console