// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #3

#include "SpeakerView.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include "Monostack.h"

SpeakerView::SpeakerView(const std::string& filename) : seating(nullptr), viewHeights(nullptr), numRows(0), numCols(0), filename(filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file.");
    }

    std::string line;
    while (std::getline(file, line)) {
        if (line == "BEGIN" || line == "END") {
            continue;
        }

        std::istringstream iss(line);
        double height;
        int rowSize = 0;

        while (iss >> height) {
            rowSize++;
        }

        if (rowSize > numCols) {
            numCols = rowSize;
        }

        numRows++;
    }

    seating = new double*[numRows];
    viewHeights = new double*[numCols];

    for (int i = 0; i < numRows; ++i) {
        seating[i] = new double[numCols];
        viewHeights[i] = new double[numCols];
    }

    file.close();
}



SpeakerView::~SpeakerView() {
    releaseMemory();
}

void SpeakerView::releaseMemory() {
    if (seating) {
        for (int i = 0; i < numRows; ++i) {
            delete[] seating[i];
        }
        delete[] seating;
    }

    if (viewHeights) {
        for (int i = 0; i < numCols; ++i) {
            delete[] viewHeights[i];
        }
        delete[] viewHeights;
    }
}

// computes how many people in each column can see
void SpeakerView::computeView() {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file.");
    }

    std::string line;
    int rowIdx = 0;

    while (std::getline(file, line)) {
        if (line == "BEGIN" || line == "END") {
            continue;
        }

        std::istringstream iss(line);
        double height;

        int colIdx = 0;
        while (iss >> height) {
            seating[rowIdx][colIdx] = height;
            colIdx++;
        }

        rowIdx++;
    }

    file.close();
}

// prints the amount of people in each column who can see
void SpeakerView::printView() const {
    for (int col = 0; col < numCols; ++col) {
        int numViewers = 0;

        for (int row = 0; row < numRows; ++row) {
            if (seating[row][col] >= viewHeights[col][numViewers - 1]) {
                viewHeights[col][numViewers] = seating[row][col];
                numViewers++;
            }
        }

        std::cout << "In column " << col << " there are " << numViewers << " that can see. Their heights are: ";

        for (int i = 0; i < numViewers; ++i) {
            std::cout << viewHeights[col][i];
            if (i < numViewers - 1) {
                std::cout << ", ";
            }
        }

        std::cout << " inches." << std::endl;
    }
}
