// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #3

#include <iostream>
#include "Monostack.h"

template <typename T>
MonoStack<T>::MonoStack(int initialSize, char o) : size(initialSize), order(o) {
    if (order != 'i' && order != 'd') {
        throw std::invalid_argument("Invalid order. Use 'i' for increasing or 'd' for decreasing.");
    }

    data = new T[size];
    top = -1;
}

template <typename T>
MonoStack<T>::~MonoStack() {
    delete[] data;
}

template <typename T>
bool MonoStack<T>::isEmpty() const {
    return top == -1;
}

template <typename T>
void MonoStack<T>::push(T value) {
    if (order == 'i') {
        while (!isEmpty() && value >= data[top]) {
            pop();
        }
    } else {
        while (!isEmpty() && value <= data[top]) {
            pop();
        }
    }

    if (top < size - 1) {
        data[++top] = value;
    }
}

template <typename T>
void MonoStack<T>::pop() {
    if (!isEmpty()) {
        top--;
    }
}

template <typename T>
T MonoStack<T>::topValue() const {
    if (isEmpty()) {
        throw std::underflow_error("Stack is empty.");
    }
    return data[top];
}

template class MonoStack<double>;  // Explicit instantiation for double
