// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #3

#ifndef SPEAKERVIEW_H
#define SPEAKERVIEW_H

#include <string>

class SpeakerView {
public:
    SpeakerView(const std::string& filename);
    ~SpeakerView();

    void computeView();
    void printView() const;

private:
    double** seating;
    double** viewHeights;
    int numRows;
    int numCols;
    std::string filename;

    void releaseMemory();
};

#endif // SPEAKERVIEW_H
