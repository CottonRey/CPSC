// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #2

#ifndef MARIO_H
#define MARIO_H
#include <iostream>
#include <fstream>

class Mario{
    public:
            Mario(int startingLives, int totalLevels, std::string output);
            ~Mario();
            int getPositionType(int** currentLevel);
            void move(int** currentLevel);
            int getLives();
            int getCoins();
            int getPowerLevel();
            void collectCoin(int** currentLevel);
            void gainLife();
            void loseLife();
            void getMushroom(int** currentLevel);
            void decreasePowerLevel();
            void takeDamage();
            void marioRandomStart();
            void increaseStreak();
            void endStreak();
            void fightGoomba(int** currentLevel);
            void fightKoopa(int** currentLevel);
            void fightBoss();
            void RunGame(int size, int coins, int nothing, int goombas, int koopas, int mushrooms);
            void printLevel(int** currentLevel, int arrSize, int currentLevelNumber);
            void printMarioStatus(int currentLevel);
            int lives;
            Level level;
            void warpPipe();
            void wrongPercentages();
    private:
            int coins;
            int powerLevel;
            int killStreak;
            int marioX;
            int marioY;
            bool gameOver;
            int levelAmount;
            bool lose;
            std::ofstream outputFile;

};
#endif
