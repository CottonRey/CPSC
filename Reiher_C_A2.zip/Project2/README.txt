Colton Reiher
2398791
reiher@chapman.edu
CPSC-350-03
Assignment #2

Worked with Julian Carbajal

----------------
Submitted Files:

FileProcessor.cpp
FileProcessor.h
main.cpp
Mario.cpp
Mario.h
input.txt
output.txt
Level.cpp
Level.h

-------
Errors:

No known compile or runtime errors, or code limitations.

One deviation from program specifications:

1. The log does not start by printing a character representation of each level in the world, as the levels are not generated all at once, and instead are generated procedurally.

-----------
References:

https://devdocs.io/cpp/
https://cplusplus.com/doc/tutorial/arrays/
https://stackoverflow.com/questions/30549819/can-i-use-an-array-in-a-case-statement
https://www.w3schools.com/cpp/cpp_arrays_loop.asp
https://stackoverflow.com/questions/12885356/random-numbers-with-different-probabilities
Worked with Julian Carbajal

-------------
Instructions:

Commands to compile into executible and run program:

g++ *.cpp -o secondProject.exe
./secondProject.exe input.txt output.txt

Running the program will run the Mario game. It takes two command line arguments, input.txt (which determines many of the values of the game), and output.txt (where the results of the game will be printed).

Mario will move through each level, interacting with each entity he comes across, until he either dies with zero lives left, or completes the last level.

The output file will show the level state each time Mario moves, as well as what Mario did on each space, and Mario's current state.