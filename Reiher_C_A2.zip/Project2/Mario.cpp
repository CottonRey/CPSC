// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #2

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "Level.h"
#include "Mario.h"


    // Mario constructor
    Mario::Mario(int startingLives, int totalLevels, std::string output) : lives(startingLives), coins(0), powerLevel(0), killStreak(0), marioX(0), marioY(0), gameOver(false), levelAmount(totalLevels), lose(false), outputFile(output) {

        if (!outputFile.is_open()) {
            std::cerr << "Failed to open the output file." << std::endl;
        }
    }


    // Checks what's at Mario's current space
    int Mario::getPositionType(int** currentLevel){
        return level.getAtIndex(currentLevel, marioX, marioY);
    }

    // Moves Mario through the level
    void Mario::move(int** currentLevel) {
        // Generate a random number between 0 and 3 to determine the direction
        int direction = rand() % 4;
        // Move Mario in the chosen direction
        switch (direction) {
            case 0:
                outputFile << "Mario moves down." << std::endl;
                outputFile << "==========" << std::endl;
                marioY++;
                if (marioY == level.getArraySize()){
                  marioY = 0;
                }
                break;
            case 1:
                outputFile << "Mario moves up." << std::endl;
                outputFile << "==========" << std::endl;
                marioY--;
                if (marioY == -1){
                  marioY = level.getArraySize() - 1;
                }
                break;
            case 2:
                outputFile << "Mario moves left." << std::endl;
                outputFile << "==========" << std::endl;
                marioX--;
                if (marioX == -1){
                  marioX = level.getArraySize() - 1;
                }
                break;
            case 3:
                outputFile << "Mario moves right." << std::endl;
                outputFile << "==========" << std::endl;
                marioX++;
                if (marioX == level.getArraySize()){
                  marioX = 0;
                }
                break;
        }
        // Check the type of the current position and interact with it accordingly
        int positionType = getPositionType(currentLevel);
        switch (positionType) {
            case 5:
                outputFile << "The position is empty." << std::endl;
                break;
            case 1:
                outputFile << "Mario collects a coin." << std::endl;
                collectCoin(currentLevel);
                break;
            case 3:
                outputFile << "Mario eats a mushroom." << std::endl;
                getMushroom(currentLevel);
                break;
            case 2:
                outputFile << "Mario engages a goomba." << std::endl;
                fightGoomba(currentLevel);
                break;
            case 4:
                outputFile << "Mario engages a koopa." << std::endl;
                fightKoopa(currentLevel);
                break;
            case 6:
                outputFile << "Mario engages the level boss." << std::endl;
                fightBoss();
                break;
            case 7:
                outputFile << "Mario enters the warp pipe." << std::endl;
                warpPipe();
                break;
        }
    }

    int Mario::getLives() {
        return lives;
    }
    int Mario::getCoins() {
        return coins;

    }
    int Mario::getPowerLevel(){
    return powerLevel;
    }

    void Mario::collectCoin(int** currentLevel) {
        coins++;
        if (coins >= 20){
            coins -= 20;
            gainLife();
        }
        currentLevel[marioX][marioY] = 5;
    }

    void Mario::gainLife(){
        lives++;
    }

    void Mario::loseLife(){
        if (lives == 0){
          outputFile << "Mario died!" << std::endl;
          lose = true;
          gameOver = true;
        } else if (lives > 0) {
          lives--;
          outputFile << "Mario lost a life!" << std::endl;
        }
    }

    void Mario::getMushroom(int** currentLevel){
        if (powerLevel < 2) {
            powerLevel++;
        }
        currentLevel[marioX][marioY] = 5;
    }

    void Mario::decreasePowerLevel(){
        if (powerLevel > 0){
            powerLevel--;
            outputFile << "Mario took damage!" << std::endl;
        }
    }

    void Mario::takeDamage() {
        if (powerLevel > 0){
            decreasePowerLevel();

        } else {
            loseLife();
        }
    }

    void Mario::marioRandomStart(){
        marioX = (std::rand() % level.getArraySize());
        marioY = (std::rand() % level.getArraySize());
    }

    void Mario::increaseStreak(){
      killStreak++;
      if (killStreak == 7){
        endStreak();
        gainLife();
        outputFile << "Mario reached a 7 kill streak and earned an extra life!" << std::endl;
      }
    }

    void Mario::endStreak(){
      killStreak = 0;
    }

    void Mario::fightGoomba(int** currentLevel) {
      if (((std::rand() % 100) + 1) >= 21){
        increaseStreak();
        outputFile << "Mario killed the goomba!" << std::endl;
        currentLevel[marioX][marioY] = 5;
      } else {
        takeDamage();
        endStreak();
      }
    }

    // Prints all the info on current Mario
    void Mario::printMarioStatus(int currentLevel){
      outputFile << "Level: " << currentLevel << "|| Mario is at position: (" << marioX << "," << marioY << "). Mario is at power level " << Mario::getPowerLevel() << ". Mario has " << Mario::getLives() << " lives left. Mario has " << Mario::getCoins() << " coins. ";
    }

    void Mario::warpPipe(){
        gameOver = true;
    }

    void Mario::printLevel(int** currentLevel, int arrSize, int currentLevelNumber){
    // Print the elements of the 2D array
    for (int i = 0; i < arrSize; i++) {
        for (int j = 0; j < arrSize; j++) {
            if (i == marioY && j == marioX){
              outputFile << "H ";
            } else {
              switch(currentLevel[j][i]){
                case 1:
                  outputFile << "c ";
                  break;
                case 2:
                  outputFile << "g ";
                  break;
                case 3:
                  outputFile << "m ";
                  break;
                case 4:
                  outputFile << "k ";
                  break;
                case 5:
                  outputFile << "x ";
                  break;
                case 6:
                  outputFile << "b ";
                  break;
                case 7:
                  outputFile << "w ";
                  break;
              }
            }
        }
        outputFile << std::endl;
    }
    outputFile << "==========" << std::endl;
    Mario::printMarioStatus(currentLevelNumber);
  }

    void Mario::fightKoopa(int** currentLevel) {
      if (((std::rand() % 100) + 1) >= 36){
        increaseStreak();
        outputFile << "Mario killed the koopa!" << std::endl;
        currentLevel[marioX][marioY] = 5;
      } else {
        takeDamage();
        endStreak();
      }
    }

    void Mario::fightBoss() {
      if (((std::rand() % 100) + 1) >= 51){
        increaseStreak();
        outputFile << "Mario killed the boss!" << std::endl;
        gameOver = true;
      } else {
        takeDamage();
        takeDamage();
        endStreak();
      }
    }

    // Run if the percentages do not add up to 100
    void Mario::wrongPercentages(){
      outputFile << "Error: The percantages of entities in the level must add to 100." << std::endl;
    }

    // Runs the game
    void Mario::RunGame(int size, int coins, int nothing, int goombas, int koopas, int mushrooms) {
      // Seed the random number generator
      srand(static_cast<unsigned int>(time(nullptr)));

      int levelNumber = 1;
      int totalMoves = 0;
      int warpPipes = 1;

      // Mario plays through levelNumber amount of levels, until he beats the final level, or loses
      while (levelNumber <= levelAmount && lose != true){
          if (levelNumber == levelAmount){
              warpPipes = 0;
          }

          int** firstLevel = level.GenerateLevel(size, coins, goombas, mushrooms, nothing, koopas, warpPipes);

          marioRandomStart();

          outputFile << "==========" << std::endl;
          Mario::printLevel(firstLevel, size, levelNumber);

          // Moves and prints to output file until gameOver
          while (gameOver != true){
              move(firstLevel);
              totalMoves++;
              Mario::printLevel(firstLevel, size, levelNumber);
          }

          // Runs if Mario dies with no lives left
          if (lose != true){
              outputFile << "Level " << levelNumber << " Complete" << std::endl;
              levelNumber++;
              gameOver = false;
          } else {
              outputFile << "Mario died on level " << levelNumber << ". " << std::endl;
          }

          // Free the allocated memory
          level.DeleteArray(firstLevel, size);
      }
      outputFile << "Game Over! Total moves: " << totalMoves;
    }

    Mario::~Mario(){
        outputFile.close();
    };
