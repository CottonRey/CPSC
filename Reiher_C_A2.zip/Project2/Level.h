// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #2

#ifndef LEVEL_H
#define LEVEL_H
#include <iostream>

class Level{
    public:
            Level();
            ~Level();
            static int** GenerateLevel(int arrSize, int coins, int goombas, int mushroom, int nothing, int koopas, int warpPipe);
            static void DeleteArray(int** arr, int arrSize);
            int getAtIndex(int** currentLevel, int currentX, int currentY);
            int getArraySize();
};
#endif
