// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#ifndef MODEL_H
#define MODEL_H

#include <string>

class Model {
public:
    Model();
    ~Model();
    std::string translateSingleConsonant(char c);

private:
    bool isConsonant(char c);
    bool isVowel(char c);
    bool isUpperCase(char c);
};

#endif
