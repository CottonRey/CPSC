// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#include "FileProcessor.h"
#include "Model.h"
#include "Translator.h"
#include <fstream>
#include <iostream>

// Default constructor
FileProcessor::FileProcessor() {}

// Default destructor
FileProcessor::~FileProcessor() {}

void FileProcessor::processFile(const std::string& inputFile, const std::string& outputFile) {
    // Create instances of Model and Translator
    Model model;
    Translator translator;

    // Opens the input file
    std::ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        std::cerr << "Error: Could not open input file." << std::endl;
        return;
    }

    // Opens the output file
    std::ofstream outFile(outputFile);
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open output file." << std::endl;
        inFile.close();
        return;
    }

    // Read the input file
    std::string line;
    while (std::getline(inFile, line)) {
        // Translate the line to Robber
        std::string translatedLine = translator.translateEnglishSentence(line);

        // Write the original text in bold and the translation in italics to the output file
        outFile << "<!DOCTYPE html>" << std::endl;
        outFile << "<html>" << std::endl;
        outFile << "<body>" << std::endl;
        outFile << std::endl;
        outFile << "<p><b>" << line << "</b></p>" << std::endl;
        outFile << std::endl;
        outFile << "<p><i>" << translatedLine << "</i></p>" << std::endl;
        outFile << std::endl;
        outFile << "</body>" << std::endl;
        outFile << "</html>" << std::endl;
    }

    // Close both files
    inFile.close();
    outFile.close();
}
