// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#include "Translator.h"
#include "Model.h" // Include the Model header

// Default constructor
Translator::Translator() {}

// Default destructor
Translator::~Translator() {}

// Method to translate English word to Robber
std::string Translator::translateEnglishWord(const std::string& word) {
    std::string result;
    Model model;
    for (char c : word) {
        if (std::isalpha(c)) {
            result += model.translateSingleConsonant(c);
        } else {
            result += c;
        }
    }
    return result;
}

// Method to translate English sentence to Robber
std::string Translator::translateEnglishSentence(const std::string& sentence) {
    std::string result;
    std::string currentWord;
    Model model;
    bool inWord = false;

    for (char c : sentence) {
        if (std::isalpha(c)) {
            currentWord += c;
            inWord = true;
        } else {
            if (inWord) {
                result += translateEnglishWord(currentWord) + " ";
                currentWord.clear();
                inWord = false;
            }
            result += c;
        }
    }

    // Last word in the sentence
    if (inWord) {
        result += translateEnglishWord(currentWord);
    }

    return result;
}
