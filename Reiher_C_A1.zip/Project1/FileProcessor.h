// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include <string>

class FileProcessor {
public:
    FileProcessor();
    ~FileProcessor();
    void processFile(const std::string& inputFile, const std::string& outputFile);
};

#endif
