Colton Reiher
2398791
reiher@chapman.edu
CPSC-350-03
Assignment #1

----------------
Submitted Files:

FileProcessor.cpp
FileProcessor.h
main.cpp
Model.cpp
Model.h
original.txt
Translation.html
Translator.cpp
Translator.h

-------
Errors:

No known compile or runtime errors, code limitations, or deviations from assignment specifications.

-----------
References:

https://devdocs.io/cpp/

-------------
Instructions:

Commands to compile into executible and run program:

g++ *.cpp -o firstProject.exe
./firstProject.exe

Running the program will translate the text in the original.txt file into Rövarspråket, writing both the original text
and the translated text into the Translation.html file.