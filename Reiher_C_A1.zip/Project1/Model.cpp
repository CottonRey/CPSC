// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#include "Model.h"

// Default constructor
Model::Model() {}

// Default destructor
Model::~Model() {}

// Method to translate a single consonant character to Robber
std::string Model::translateSingleConsonant(char c) {
    std::string result;
    if (isConsonant(c)) {
        result += c;
        if (isUpperCase(c)) {
            result += 'O';
        } else {
            result += 'o';
        }
        result += c;
    } else {
        result += c;
    }
    return result;
}

// Function to check if a character is a consonant
bool Model::isConsonant(char c) {
    return std::isalpha(c) && !isVowel(c);
}

// Function to check if a character is a vowel
bool Model::isVowel(char c) {
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
}

// Function to check if a character is uppercase
bool Model::isUpperCase(char c) {
    return std::isupper(c);
}
