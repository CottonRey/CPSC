// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#ifndef TRANSLATOR_H
#define TRANSLATOR_H

#include <string>

class Translator {
public:
    Translator();
    ~Translator();
    std::string translateEnglishWord(const std::string& word);
    std::string translateEnglishSentence(const std::string& sentence);
};

#endif
