// Colton Reiher
// 2398791
// reiher@chapman.edu
// CPSC-350-03
// Assignment #1

#include "FileProcessor.h"

int main() {
    FileProcessor fileProcessor;
    fileProcessor.processFile("original.txt", "Translation.html");
    return 0;
}
